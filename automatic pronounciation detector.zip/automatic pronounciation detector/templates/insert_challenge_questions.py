from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017/")
db = client["pronunciation_app"]
challenge_collection = db["challenge_questions"]

# Optional: Clear existing entries
challenge_collection.delete_many({})

domains = ["AI/ML", "Data Science", "Cybersecurity", "Latest Technology", "Web Development"]

challenge_questions = []

for domain in domains:
    # Beginner - Speak the Word (5 words)
    for word in ["Algorithm", "Model", "Training", "Accuracy", "Prediction"]:
        challenge_questions.append({
            "domain": domain,
            "level": "Beginner",
            "type": "speak_word",
            "question": word
        })

    # Intermediate - Audio MCQ (5 questions)
    mcqs = [
        {
            "question": "Which of these is a supervised learning algorithm?",
            "options": ["KMeans", "Decision Tree", "Apriori", "DBSCAN"],
            "answer": "Decision Tree"
        },
        {
            "question": "Which tool is used for data analysis?",
            "options": ["React", "Flask", "Pandas", "Linux"],
            "answer": "Pandas"
        },
        {
            "question": "What ensures secure web communication?",
            "options": ["HTTP", "SSL", "IP", "MAC"],
            "answer": "SSL"
        },
        {
            "question": "Which is a trending AI chatbot?",
            "options": ["Cortana", "Siri", "ChatGPT", "DuckDuckGo"],
            "answer": "ChatGPT"
        },
        {
            "question": "Which language is used for frontend web development?",
            "options": ["Python", "HTML", "MySQL", "Java"],
            "answer": "HTML"
        }
    ]
    for mcq in mcqs:
        challenge_questions.append({
            "domain": domain,
            "level": "Intermediate",
            "type": "audio_mcq",
            **mcq
        })

    # Advanced - Fill in the Blank (5 questions)
    fill_blanks = [
        {"question": "Convolutional _____ Network is used in image recognition.", "answer": "Neural"},
        {"question": "Pandas is used to handle structured _____.", "answer": "data"},
        {"question": "A strong _____ prevents unauthorized access.", "answer": "password"},
        {"question": "Edge _____ allows data processing near the source.", "answer": "computing"},
        {"question": "_____ is used to make websites interactive.", "answer": "JavaScript"}
    ]
    for blank in fill_blanks:
        challenge_questions.append({
            "domain": domain,
            "level": "Advanced",
            "type": "fill_blank",
            **blank
        })

# Insert into MongoDB
challenge_collection.insert_many(challenge_questions)
print(f"✅ Inserted {len(challenge_questions)} challenge level questions into MongoDB.")
