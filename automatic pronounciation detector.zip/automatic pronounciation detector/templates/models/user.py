from flask_login import UserMixin
from bson.objectid import ObjectId

class User(UserMixin):
    def __init__(self, user_doc):
        self.id = str(user_doc["_id"])
        self.username = user_doc["username"]

    @staticmethod
    def get_by_id(mongo, user_id):
        user = mongo.db.users.find_one({"_id": ObjectId(user_id)})
        return User(user) if user else None

    @staticmethod
    def get_by_username(mongo, username):
        user = mongo.db.users.find_one({"username": username})
        return User(user) if user else None
