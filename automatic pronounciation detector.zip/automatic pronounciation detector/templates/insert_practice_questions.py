from pymongo import MongoClient

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["pronunciation_app"]
practice_questions_collection = db["practice_questions"]

# Clear existing practice questions if needed
practice_questions_collection.delete_many({})  # Optional

# Questions for multiple domains
practice_questions = [
    # --- AI Domain ---
    {"domain": "ai", "level": "beginner", "type": "pronunciation", "question": "Artificial Intelligence", "answer": "Artificial Intelligence"},
    {"domain": "ai", "level": "beginner", "type": "listening", "question": "What does AI stand for?", "options": ["Artificial Intelligence", "Automatic Input", "Auto Intelligence", "Active Internet"], "answer": "Artificial Intelligence"},
    {"domain": "ai", "level": "intermediate", "type": "pronunciation", "question": "Neural Network", "answer": "Neural Network"},
    {"domain": "ai", "level": "intermediate", "type": "listening", "question": "Which technique is used for image recognition?", "options": ["RNN", "CNN", "LSTM", "GAN"], "answer": "CNN"},
    {"domain": "ai", "level": "advanced", "type": "pronunciation", "question": "Reinforcement Learning", "answer": "Reinforcement Learning"},
    {"domain": "ai", "level": "advanced", "type": "listening", "question": "What algorithm uses reward-based training?", "options": ["Supervised Learning", "Unsupervised Learning", "Reinforcement Learning", "Deep Learning"], "answer": "Reinforcement Learning"},

    # --- Data Science Domain ---
    {"domain": "data_science", "level": "beginner", "type": "pronunciation", "question": "Data Cleaning", "answer": "Data Cleaning"},
    {"domain": "data_science", "level": "beginner", "type": "listening", "question": "Which library is used for data manipulation?", "options": ["NumPy", "Pandas", "Matplotlib", "TensorFlow"], "answer": "Pandas"},
    {"domain": "data_science", "level": "intermediate", "type": "pronunciation", "question": "Exploratory Data Analysis", "answer": "Exploratory Data Analysis"},
    {"domain": "data_science", "level": "intermediate", "type": "listening", "question": "Which library helps in data visualization?", "options": ["Seaborn", "Scikit-learn", "Flask", "Jupyter"], "answer": "Seaborn"},
    {"domain": "data_science", "level": "advanced", "type": "pronunciation", "question": "Dimensionality Reduction", "answer": "Dimensionality Reduction"},
    {"domain": "data_science", "level": "advanced", "type": "listening", "question": "Which technique is used to reduce features?", "options": ["Clustering", "Classification", "PCA", "Regression"], "answer": "PCA"},

    # --- Cybersecurity Domain ---
    {"domain": "cybersecurity", "level": "beginner", "type": "pronunciation", "question": "Firewall", "answer": "Firewall"},
    {"domain": "cybersecurity", "level": "beginner", "type": "listening", "question": "What prevents unauthorized access?", "options": ["Firewall", "Antivirus", "VPN", "Proxy"], "answer": "Firewall"},
    {"domain": "cybersecurity", "level": "intermediate", "type": "pronunciation", "question": "Encryption", "answer": "Encryption"},
    {"domain": "cybersecurity", "level": "intermediate", "type": "listening", "question": "What converts data into unreadable form?", "options": ["Hashing", "Encryption", "Masking", "Tokenization"], "answer": "Encryption"},
    {"domain": "cybersecurity", "level": "advanced", "type": "pronunciation", "question": "Penetration Testing", "answer": "Penetration Testing"},
    {"domain": "cybersecurity", "level": "advanced", "type": "listening", "question": "Which test checks for system vulnerabilities?", "options": ["Phishing", "Penetration Testing", "Authentication", "Validation"], "answer": "Penetration Testing"},

    # --- Web Development Domain ---
    {"domain": "web_development", "level": "beginner", "type": "pronunciation", "question": "HTML", "answer": "HTML"},
    {"domain": "web_development", "level": "beginner", "type": "listening", "question": "Which language structures a webpage?", "options": ["CSS", "JavaScript", "HTML", "PHP"], "answer": "HTML"},
    {"domain": "web_development", "level": "intermediate", "type": "pronunciation", "question": "JavaScript", "answer": "JavaScript"},
    {"domain": "web_development", "level": "intermediate", "type": "listening", "question": "Which language adds interactivity to websites?", "options": ["Python", "HTML", "CSS", "JavaScript"], "answer": "JavaScript"},
    {"domain": "web_development", "level": "advanced", "type": "pronunciation", "question": "React Framework", "answer": "React Framework"},
    {"domain": "web_development", "level": "advanced", "type": "listening", "question": "Which is a front-end JavaScript framework?", "options": ["Flask", "React", "Django", "Node.js"], "answer": "React"},

    # --- Latest Technology Domain ---
    {"domain": "latest_technology", "level": "beginner", "type": "pronunciation", "question": "Cloud Computing", "answer": "Cloud Computing"},
    {"domain": "latest_technology", "level": "beginner", "type": "listening", "question": "Which tech provides on-demand storage?", "options": ["Big Data", "Cloud Computing", "IoT", "AI"], "answer": "Cloud Computing"},
    {"domain": "latest_technology", "level": "intermediate", "type": "pronunciation", "question": "Blockchain", "answer": "Blockchain"},
    {"domain": "latest_technology", "level": "intermediate", "type": "listening", "question": "Which tech enables secure digital ledger?", "options": ["Cloud", "Blockchain", "Git", "Databases"], "answer": "Blockchain"},
    {"domain": "latest_technology", "level": "advanced", "type": "pronunciation", "question": "Quantum Computing", "answer": "Quantum Computing"},
    {"domain": "latest_technology", "level": "advanced", "type": "listening", "question": "Which tech uses qubits for processing?", "options": ["AI", "Quantum Computing", "Machine Learning", "Data Mining"], "answer": "Quantum Computing"},
]

# Insert into MongoDB
practice_questions_collection.insert_many(practice_questions)
print("✅ Multiple domain practice questions inserted into MongoDB.")
