from flask_login import UserMixin
from bson import ObjectId
from pymongo import MongoClient

class User(UserMixin):
    def __init__(self, user_data):
        self.id = str(user_data["_id"])
        self.username = user_data["username"]

    @staticmethod
    def get(user_id):
        # Avoid circular import by initializing DB here
        client = MongoClient("mongodb://localhost:27017/")
        db = client["pronunciation_app"]
        users_collection = db["users"]

        user_data = users_collection.find_one({"_id": ObjectId(user_id)})
        if user_data:
            return User(user_data)
        return None
