from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from user_model import User
from pymongo import MongoClient
from bson import ObjectId
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client["pronunciation_app"]
users_collection = db["users"]
practice_collection = db["practice_questions"]
challenge_collection = db["challenge_questions"]
audio_collection = db["audio_submissions"]

# Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Audio folder
UPLOAD_FOLDER = "static/recordings"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

# ---------------- ROUTES ----------------

@app.route('/')
def index():
    return redirect(url_for('login'))

# ---------- LOGIN / REGISTER ----------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_data = users_collection.find_one({"username": username})
        if user_data and user_data["password"] == password:
            user = User(user_data)
            login_user(user)
            return redirect(url_for("home"))
        else:
            flash("Invalid credentials")
            return redirect(url_for("login"))
    return render_template("login.html")

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        existing_user = users_collection.find_one({"username": username})
        if existing_user:
            flash("Username already exists.")
            return redirect(url_for("register"))
        users_collection.insert_one({"username": username, "password": password})
        flash("Registration successful! Please login.")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

# ---------- HOME ----------
@app.route('/home')
@login_required
def home():
    return render_template("home.html", username=current_user.username)

# ---------- TEXT TO VOICE ----------
@app.route('/text-to-voice')
@login_required
def text_to_voice():
    return render_template('text_to_voice.html')

# ---------- VOICE TO TEXT ----------
@app.route('/voice-to-text')
@login_required
def voice_to_text():
    return render_template('voice_to_text.html')

# ---------- PRACTICE LEVEL ----------
@app.route('/practice-level', methods=['GET'])
@login_required
def practice_level():
    selected_domain = request.args.get('domain')
    selected_level = request.args.get('level')

    domains = practice_collection.distinct('domain')  # To populate the domain dropdown

    questions = []
    if selected_domain and selected_level:
        questions = list(practice_collection.find({
            'domain': selected_domain,
            'level': selected_level
        }))

    return render_template(
        'practice_level.html',
        questions=questions,
        selected_domain=selected_domain,
        selected_level=selected_level,
        domains=domains
    )


# ---------- CHALLENGE LEVEL ----------
@app.route('/challenge-level', methods=['GET'])
@login_required
def challenge_level():
    selected_domain = request.args.get('domain')
    selected_level = request.args.get('level')

    # Get all available domains from DB
    all_domains = db.challenge_questions.distinct('domain')

    challenge_questions = []
    if selected_domain and selected_level:
        challenge_questions = list(db.challenge_questions.find({
            'domain': selected_domain,
            'level': selected_level
        }))

    return render_template('challenge_level.html',
                           domains=all_domains,
                           selected_domain=selected_domain,
                           selected_level=selected_level,
                           questions=challenge_questions)

# ---------- AUDIO UPLOAD ----------
@app.route('/upload-audio', methods=['POST'])
@login_required
def upload_audio():
    audio_file = request.files['audio']
    if audio_file:
        filename = f"{current_user.username}_{datetime.now().strftime('%Y%m%d%H%M%S')}.webm"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        audio_file.save(filepath)

        audio_collection.insert_one({
            "user": current_user.username,
            "filename": filename,
            "timestamp": datetime.utcnow()
        })
        return "Audio uploaded successfully", 200
    return "No audio file", 400

# ---------- HELP ----------
@app.route('/help')
@login_required
def help():
    return render_template("help.html")

# ---------- SUGGESTION BOX ----------
@app.route('/suggestion-box', methods=['GET', 'POST'])
@login_required
def suggestion_box():
    return render_template('suggestion_box.html')
@app.route('/avatar-bar')
@login_required
def avatar_bar():
    return "<h2>Avatar Bar is under development.</h2>"
@app.route('/sound-toggle')
@login_required
def sound_toggle():
    return "<h2>Sound Toggle feature is under development.</h2>"


# ---------------- MAIN ----------------
if __name__ == '__main__':
    app.run(debug=True)
